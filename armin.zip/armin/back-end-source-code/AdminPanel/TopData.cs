﻿namespace AdminPanel
{
    public class TopData
    {
        public string Followers { get; set; }
        public string FollowersPercent { get; set; }
        public string StoryViews { get; set; }
        public string StoryViewsPercent { get; set; }
        public string Explore { get; set; }
        public string ExplorePercent { get; set; }
        public string ConversionRate { get; set; }
        public string ConversionRatePercent { get; set; }
    }
}
