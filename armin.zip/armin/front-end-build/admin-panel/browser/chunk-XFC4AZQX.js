import"./chunk-4CLCTAJ7.js";var t=[{path:"",loadComponent:()=>import("./chunk-X25DVJUE.js").then(o=>o.DashboardComponent),data:{title:$localize`Dashboard`}}];export{t as routes};
